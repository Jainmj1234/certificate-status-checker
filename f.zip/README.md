# certificate-status-checker
It is just a login form which checks the database and returns the result if some condition is true
